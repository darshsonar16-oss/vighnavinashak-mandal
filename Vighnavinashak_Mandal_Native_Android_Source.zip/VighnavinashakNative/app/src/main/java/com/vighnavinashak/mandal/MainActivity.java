package com.vighnavinashak.mandal;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
  int maroon=Color.rgb(126,36,21), saffron=Color.rgb(183,71,25), cream=Color.rgb(255,248,239), ink=Color.rgb(42,36,32);
  LinearLayout root, content, nav; android.content.SharedPreferences prefs;
  JSONArray receipts, donors, expenses; String screen="home";
  @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("mandal",MODE_PRIVATE); receipts=load("receipts"); donors=load("donors"); expenses=load("expenses"); showHome();}
  JSONArray load(String key){try{return new JSONArray(prefs.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
  void save(String key,JSONArray arr){prefs.edit().putString(key,arr.toString()).apply();}
  int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
  LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
  LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
  void base(String title){
    root=column();root.setBackgroundColor(cream);setContentView(root);
    LinearLayout header=column();header.setPadding(dp(20),dp(16),dp(20),dp(17));header.setBackground(bg(maroon,0));
    TextView brand=text("॥ श्री गणेशाय नमः ॥",12,0xFFFFD7A5,true); header.addView(brand);
    TextView h=text(title,22,Color.WHITE,true);header.addView(h); TextView sub=text("श्री विघ्नविनाशक मित्र मंडळ",13,0xFFFFE7D2,false);header.addView(sub);root.addView(header);
    ScrollView sc=new ScrollView(this); content=column();content.setPadding(dp(16),dp(16),dp(16),dp(18));sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    nav=row();nav.setPadding(dp(4),dp(6),dp(4),dp(6));nav.setBackgroundColor(Color.WHITE);String[][] items={{"⌂","होम"},{"＋","रसीद"},{"♙","डोनर"},{"₹","खर्च"},{"⚙","सेटिंग"}};
    for(String[] it:items){TextView b=text(it[0]+"\n"+it[1],11,maroon,true);b.setGravity(Gravity.CENTER);nav.addView(b,new LinearLayout.LayoutParams(0,dp(52),1));b.setOnClickListener(v->{switch(it[1]){case "होम":showHome();break;case "रसीद":receiptForm();break;case "डोनर":donorForm();break;case "खर्च":expenseForm();break;default:settings();}});}root.addView(nav);
  }
  void card(String title,String body){LinearLayout c=column();c.setPadding(dp(15),dp(12),dp(15),dp(12));c.setBackground(bg(Color.WHITE,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(12);content.addView(c,p);c.addView(text(title,15,maroon,true));TextView b=text(body,13,ink,false);b.setPadding(0,dp(5),0,0);c.addView(b);}
  void button(String label,Runnable action){TextView b=text(label,15,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),dp(13),dp(12),dp(13));b.setBackground(bg(saffron,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);content.addView(b,p);b.setOnClickListener(v->action.run());}
  EditText field(String hint, int type){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint);e.setInputType(type);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(bg(Color.WHITE,10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);content.addView(e,p);return e;}
  void showHome(){screen="home";base("मंडळ डैशबोर्ड");double total=0,exp=0;for(int i=0;i<receipts.length();i++)total+=receipts.optJSONObject(i).optDouble("amount");for(int i=0;i<expenses.length();i++)exp+=expenses.optJSONObject(i).optDouble("amount");
    TextView welcome=text("🙏 गणपति बाप्पा मोरया!",18,maroon,true);welcome.setPadding(0,0,0,dp(14));content.addView(welcome);
    LinearLayout stats=row();content.addView(stats);stats.addView(stat("कुल जमा","₹ "+fmt(total)),new LinearLayout.LayoutParams(0,dp(92),1));View gap=new View(this);stats.addView(gap,new LinearLayout.LayoutParams(dp(8),1));stats.addView(stat("कुल खर्च","₹ "+fmt(exp)),new LinearLayout.LayoutParams(0,dp(92),1));
    LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(8);TextView d=stat("डोनर",String.valueOf(donors.length()));stats.addView(d,new LinearLayout.LayoutParams(0,dp(92),1));
    card("आज का काम","रसीद बनाएं, डोनर की जानकारी सेव करें और मंडल के आय-खर्च का हिसाब रखें। डेटा इस फोन में सेव होता है।");button("＋  नई रसीद बनाएं",this::receiptForm);button("₹  नया खर्च दर्ज करें",this::expenseForm);button("▤  रिपोर्ट देखें",this::reports);button("📄  रसीदों की सूची",this::receiptList);
  }
  View stat(String title,String value){LinearLayout c=column();c.setPadding(dp(12),dp(10),dp(8),dp(8));c.setBackground(bg(Color.WHITE,14));c.addView(text(title,12,0xFF77665D,false));c.addView(text(value,19,maroon,true));return c;}
  String fmt(double d){return String.format(java.util.Locale.US,"%,.2f",d);}
  void receiptForm(){screen="receipt";base("नई रसीद");card("दान की रसीद","जानकारी भरें और रसीद सेव करें।");EditText name=field("दाता का पूरा नाम",1);EditText phone=field("मोबाइल नंबर",3);EditText amount=field("रकम (₹)",2|8192);EditText purpose=field("दान का उद्देश्य (वैकल्पिक)",1);button("रसीद सेव करें और शेयर करें",()->{String n=name.getText().toString().trim(), ph=phone.getText().toString().trim();double a;try{a=Double.parseDouble(amount.getText().toString().trim());}catch(Exception ex){toast("सही रकम भरें");return;}if(n.isEmpty()||a<=0){toast("नाम और सही रकम भरें");return;}String id="VVM-"+new SimpleDateFormat("yyMMdd-HHmmss",Locale.US).format(new Date());JSONObject o=new JSONObject();try{o.put("id",id);o.put("name",n);o.put("phone",ph);o.put("amount",a);o.put("purpose",purpose.getText().toString());o.put("date",new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date()));receipts.put(o);save("receipts",receipts);JSONObject donor=new JSONObject();donor.put("name",n);donor.put("phone",ph);donors.put(donor);save("donors",donors);}catch(Exception ignored){}shareReceipt(id,n,ph,a,purpose.getText().toString());});button("रद्द करें",this::showHome);}
  void shareReceipt(String id,String name,String phone,double amount,String purpose){String msg="॥ श्री गणेशाय नमः ॥\nश्री विघ्नविनाशक मित्र मंडळ\nदान रसीद: "+id+"\nदाता: "+name+"\nमोबाइल: "+phone+"\nरकम: ₹"+fmt(amount)+"\nउद्देश्य: "+purpose+"\nतारीख: "+new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date())+"\nआपके सहयोग के लिए धन्यवाद!\nगणपति बाप्पा मोरया!";try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,msg);startActivity(Intent.createChooser(i,"रसीद शेयर करें"));}catch(Exception e){toast(msg);}showHome();}
  void donorForm(){screen="donors";base("डोनर रिकॉर्ड");EditText name=field("डोनर का नाम",1);EditText phone=field("मोबाइल नंबर",3);button("डोनर सेव करें",()->{if(name.getText().toString().trim().isEmpty()){toast("नाम भरें");return;}JSONObject o=new JSONObject();try{o.put("name",name.getText().toString().trim());o.put("phone",phone.getText().toString().trim());donors.put(o);save("donors",donors);toast("डोनर सेव हो गया");donorForm();}catch(Exception e){toast("सेव नहीं हुआ");}});card("कुल डोनर",String.valueOf(donors.length()));for(int i=donors.length()-1;i>=0;i--){JSONObject o=donors.optJSONObject(i);card(o.optString("name"),o.optString("phone"));}}
  void expenseForm(){screen="expense";base("खर्च दर्ज करें");EditText title=field("खर्च का विवरण",1);EditText amount=field("रकम (₹)",2|8192);EditText note=field("नोट (वैकल्पिक)",1);button("खर्च सेव करें",()->{double a;try{a=Double.parseDouble(amount.getText().toString().trim());}catch(Exception e){toast("सही रकम भरें");return;}if(title.getText().toString().trim().isEmpty()||a<=0){toast("विवरण और रकम भरें");return;}JSONObject o=new JSONObject();try{o.put("title",title.getText().toString());o.put("amount",a);o.put("note",note.getText().toString());o.put("date",new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date()));expenses.put(o);save("expenses",expenses);toast("खर्च सेव हो गया");showHome();}catch(Exception e){toast("सेव नहीं हुआ");}});}
  void reports(){base("हिसाब-किताब रिपोर्ट");double income=0,out=0;for(int i=0;i<receipts.length();i++)income+=receipts.optJSONObject(i).optDouble("amount");for(int i=0;i<expenses.length();i++)out+=expenses.optJSONObject(i).optDouble("amount");card("कुल दान / जमा","₹ "+fmt(income));card("कुल खर्च","₹ "+fmt(out));card("बाकी राशि","₹ "+fmt(income-out));card("रिकॉर्ड","रसीदें: "+receipts.length()+"\nडोनर एंट्री: "+donors.length()+"\nखर्च एंट्री: "+expenses.length());button("रसीद सूची",this::receiptList);button("होम पर जाएं",this::showHome);}
  void receiptList(){base("रसीद सूची");if(receipts.length()==0)card("अभी कोई रसीद नहीं","नई रसीद बनाने के लिए नीचे बटन दबाएं।");for(int i=receipts.length()-1;i>=0;i--){JSONObject o=receipts.optJSONObject(i);card(o.optString("name")+" — ₹"+fmt(o.optDouble("amount")),o.optString("id")+" • "+o.optString("date")+"\n"+o.optString("phone"));}button("＋ नई रसीद",this::receiptForm);}
  void settings(){base("मंडल सेटिंग्स");EditText insta=field("Instagram ID",1);EditText youtube=field("YouTube चैनल लिंक",1);EditText contact=field("संपर्क नंबर",3);insta.setText(prefs.getString("insta",""));youtube.setText(prefs.getString("youtube",""));contact.setText(prefs.getString("contact",""));button("सेटिंग्स सेव करें",()->{prefs.edit().putString("insta",insta.getText().toString()).putString("youtube",youtube.getText().toString()).putString("contact",contact.getText().toString()).apply();toast("सेटिंग्स सेव हो गईं");});card("महत्वपूर्ण जानकारी","फिलहाल रसीद, डोनर और खर्च का डेटा इसी मोबाइल में सेव होता है। सभी मोबाइलों में एक जैसा डेटा देखने के लिए सुरक्षित ऑनलाइन डेटाबेस और लॉगिन को अलग से जोड़ना होगा।");button("डेटा एक्सपोर्ट / शेयर",()->{String backup="श्री विघ्नविनाशक मित्र मंडळ\nरसीदें: "+receipts+"\nडोनर: "+donors+"\nखर्च: "+expenses;Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,backup);startActivity(Intent.createChooser(i,"बैकअप शेयर करें"));});}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  @Override public void onBackPressed(){if(!screen.equals("home"))showHome();else super.onBackPressed();}
}
